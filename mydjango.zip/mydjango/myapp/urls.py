
from django.urls import path
from .import views

urlpatterns = [
    
    path('mymsg/',views.test),
    path('registration/',views.signup),
    path('login/',views.signin,name='login' ),
    path('pred/',views.predection,name='pred' ),
]
