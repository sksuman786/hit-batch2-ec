from django.shortcuts import render,redirect
from django.http import HttpResponse

from myapp.models import UserInfo

import joblib
import numpy as np
import warnings
import time

# Create your views here.


def test(request):
	msg = 'Good Afternoon'

	return HttpResponse(msg)



def signup(request):

	nam = request.POST.get('nm')
	mail = request.POST.get('em')
	pas = request.POST.get('ps')
	address = request.POST.get('ad')

	if nam !=None and mail !=None and pas !=None and address !=None :

		UserInfo.objects.create(
			name = nam,
			email = mail,
			password = pas,
			address = address,
		)

		return render(request,'login.html')
	else:
		return render(request, 'signup.html')

	return render(request, 'signup.html') 



def signin(request):

	mail = request.POST.get('em')
	pas = request.POST.get('ps')

	er = {}
	try:

		db = UserInfo.objects.get(email = mail)
		
		if db:
			if db.password == pas:
				# return render(request, 'test.html')
				return redirect('pred')
			else:
				er['x'] = "Error: Password missmatch" 
		else:
			er['x'] = 'Error: Email does not exists'
	except Exception as e:
		er['x'] = e
		
	return render(request,'login.html',er)






def predection(request):

	

	# --- Load trained AI model ---
	model = joblib.load("C:/Users/SKSUM/OneDrive/Desktop/hit-2/mydjango/myapp/model.pkl")

	try:
	    # --- Manual input instead of POST request ---
	    temp = request.POST.get('tm')
	    hum = request.POST.get('hs')
	    gas = request.POST.get('gs')

	    # Prepare model input
	    X = np.array([[temp, hum, gas]])

	    # Run model prediction
	    warnings.filterwarnings("ignore", category=UserWarning)
	    prediction = model.predict(X)[0]

	    # Interpret prediction
	    if prediction == 0:
	        message = "Good"
	    elif prediction == 1:
	        message = "Moderate"
	    else:
	        message = "Poor"

	    # Create latest data record
	    latest_data = {
	        "temperature": temp,
	        "humidity": hum,
	        "gas_value": gas,
	        "air_quality": message,
	        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
	    }

	    if message:

	    	return render(request, 'index.html',latest_data)

	   
	except Exception as e:
	    print("Invalid input, try again.", e)

	return render(request, 'test.html')
